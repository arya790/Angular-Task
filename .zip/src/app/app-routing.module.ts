import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './auth/register/register.component';
import { AuthGuard } from './auth/guard/auth.guard';
import { HomeGuard } from './auth/guard/home.guard';

const routes: Routes = [
  {
    path: 'login',canActivate: [HomeGuard],
    loadChildren: () => import('../app/auth/auth.module').then(m => m.AuthModule)
  },
  {
    path: 'home',canActivate: [AuthGuard],
    loadChildren: () => import('../app/homeModules/home/home.module').then(m => m.HomeModule)
  },
  {path:"register",component:RegisterComponent},

  {
    path: '',
    pathMatch: "full",
    redirectTo: "login"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
