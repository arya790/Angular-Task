import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { registerForm } from '../interface/auth.interface';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  apiUrl: any = 'http://localhost:3000/register'





   // getEmployeesData
   getRegisterData(): Observable<any> {
    return this.http.get<any[]>(`${this.apiUrl}`)
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

    // post register
    register(data: registerForm): Observable<any> {
      console.log("data", data)
      return this.http.post<any[]>(`${this.apiUrl}`, data).pipe(
        map((response: any) => {
          return response;
        })
      );
    }
  
}
