import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Route, Router, RouterStateSnapshot, UrlSegment, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  localValue:any
  constructor( private router: Router) {
    this.isLogginValue();
  }

  isLogginValue(){
   this.localValue= localStorage.getItem("Info")
  }

  canActivate(): boolean {
    if (this.localValue !== null && this.localValue !== undefined) {
      return true;
    } else {
      this.router.navigate(['/login']);
      return false;
    }
  }

  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if(this.localValue !== null && this.localValue !== undefined) {
        this.router.navigate(['/home/dashboard']);
        return false;
      }
      return true;
  }
  
  
  
  
  
  
  
  
  
}
