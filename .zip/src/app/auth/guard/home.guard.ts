import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HomeGuard implements CanActivate {
  localValue:any
  constructor( private router: Router) {
    this.isLogginValue();
  }

  isLogginValue(){
   this.localValue= localStorage.getItem("Info")
  }

  canActivate(): boolean {
    if (this.localValue !== null && this.localValue !== undefined) {
      this.router.navigate(['/home/dashboard']);
      return false
    } else {
      return true
    }
  }
  
}
