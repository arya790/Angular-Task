export interface registerForm{
    name:string
    email:string
    password:string
}
export interface login{
    name:string
    email:string
    password:string
}