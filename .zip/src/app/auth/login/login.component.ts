import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../Providers/auth.service';
import { login } from '../interface/auth.interface';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  showLoader: boolean = false
  loginForm: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(8)]),
  });
  controls: any;
  adminEmail:any='choudharyarya7906@gmail.com'
  showPassword: boolean = false;
  passwordType: any = "password";
  emailValue: any
  passwordValue: any
  registerData: login[] = []
info:any=true
  constructor(
    private router: Router,
    private toastr: ToastrService,
    private auth: AuthService
  ) {
    this.controls = this.loginForm.controls;
  }

  ngOnInit(): void {
    this.getRegisterData();
  }


  // getRegisterData
  getRegisterData() {
    this.auth.getRegisterData().subscribe((res: any) => {
      console.log(res, "res==================>>>>>>>>>>")
      this.registerData = res
    })
  }

  // hideShowPassword
  switch() {
    this.showPassword = this.showPassword == true ? false : true;
    this.passwordType = this.showPassword == true ? "text" : "password";
  }

  // isEmailInArray
  isEmailInArray(emailToFind: string): boolean {
    return this.registerData.some(user => user.email === emailToFind);
  }


  // login
  Login() {
    localStorage.setItem("Info",this.info)
    this.getRegisterData();
    if (this.loginForm.valid) {
      if (this.loginForm.controls['email'].value === "choudharyarya7906@gmail.com" && this.loginForm.controls['password'].value === "password") {
        localStorage.setItem("role",this.adminEmail)
        this.router.navigate(['/home/dashboard']);
        this.toastr.success("Login Successfully");
      }else{
        const emailToCheck = this.loginForm.controls['email'].value
        const isEmailFound = this.isEmailInArray(emailToCheck);
         if (isEmailFound) {
          this.router.navigate(['/home/petManagement'])
          this.toastr.success("EmailFound Successfully");
        } else {
          this.toastr.error("Email Not found!!...");
          this.toastr.error("Register  Yourself first...");
        }
      }
     
    }
    
  }
}
