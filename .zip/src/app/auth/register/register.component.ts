import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../Providers/auth.service';
import { registerForm } from '../interface/auth.interface';
import { NgxUiLoaderService } from 'ngx-ui-loader';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  controls: any;
  showLoader=false
  showPassword:boolean = false;
  passwordType :any = "password";
  registerForm: FormGroup = new FormGroup({
    name:new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required,Validators.minLength(8)]),
  });
  constructor( private router:Router,
    private toastr: ToastrService,
    private authService:AuthService,
    private ngxService: NgxUiLoaderService,) { 
    this.controls=this.registerForm.controls
  }

  ngOnInit(): void {
  }

  // hideShowPassword
  switch(){
    this.showPassword = this.showPassword == true?false:true;
    this.passwordType = this.showPassword == true?"text":"password";
  }

  Register(){
    if(this.registerForm.valid){
      let obj:registerForm={
        name:this.registerForm.controls['name'].value,
        email:this.registerForm.controls['email'].value,
        password:this.registerForm.controls['password'].value,
      }
      console.log(obj)
      this.showLoader = true
      this.ngxService.start();
      this.authService.register(obj).subscribe((res:any)=>{
        this.showLoader = false
        this.ngxService.stop();
        this.toastr.success("Resgistered Sucessfully")
        this.router.navigate(['/login'])
      })

    }

  }

}
