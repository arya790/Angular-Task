import { Component, OnInit } from '@angular/core';
import { VeterinaryService } from '../../pet-service/Providers/veterinary.service';
import { PetsService } from '../../pet-manage/providers/pets.service';
import { AuthService } from 'src/app/auth/Providers/auth.service';

@Component({
  selector: 'app-dash-info',
  templateUrl: './dash-info.component.html',
  styleUrls: ['./dash-info.component.scss']
})
export class DashInfoComponent implements OnInit {
  totalServices: any
  totalPets: any
  petsData: any = []
  allServiceData:any=[]
  registerData: any
  petsName: any
  serviceName:any
  priceOfService:any
  petsCount: any
  show:any
  showData: any
  constructor(private petService: VeterinaryService,
    private petsService: PetsService,
    private auth: AuthService) { }

  ngOnInit(): void {
    this.getPetsRecordData();
    this.getPetsServiceData();
    this.getAllRegisteredData();
  }


  // totalPets
  getPetsRecordData() {
    this.showData=false
    this.petsService.getPetsData().subscribe((res: any) => {
      this.petsData = res
      this.totalPets = res.length;
      let name = [];
      let count = [];
      for (let i = 0; i < this.petsData.length; i++) {
        name.push(this.petsData[i].petName);
        count.push(this.petsData[i].NoOfPets);
      }
      this.petsName = name
      this.petsCount = count
      this.showData = true

    })
  }


  // totalServices
  getPetsServiceData() {
    this.show=false
    this.petService.getPetsServiceData().subscribe((res: any) => {
      this.allServiceData=res
      this.totalServices = res.length
      let name = [];
      let price = [];
      for (let i = 0; i < this.allServiceData.length; i++) {
        name.push(this.allServiceData[i].name);
        price.push(this.allServiceData[i].price);
      }
      this.serviceName = name
      this.priceOfService = price
      this.show = true

    })
    
  }

  // getRegisterAllData
  getAllRegisteredData() {
    this.auth.getRegisterData().subscribe((res: any) => {
      this.registerData = res.length
    })
  }

}
