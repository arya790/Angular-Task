import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashInfoComponent } from './dash-info/dash-info.component';

const routes: Routes = [
  {path:"",component:DashInfoComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
