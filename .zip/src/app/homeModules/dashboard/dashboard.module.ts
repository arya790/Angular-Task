import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashInfoComponent } from './dash-info/dash-info.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatGridListModule } from '@angular/material/grid-list';
// import { FlexLayoutModule } from '@angular/flex-layout';
import { ChartsModule } from 'ng2-charts';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { DoughnutChartComponent } from './doughnut-chart/doughnut-chart.component';

@NgModule({
  declarations: [
    DashInfoComponent,
    PieChartComponent,
    DoughnutChartComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    MatGridListModule,
    FormsModule,
    MatTableModule,
    ReactiveFormsModule,
    MatNativeDateModule,
    MatOptionModule,
    // InfoCardModule,
    ChartsModule,
    MatCardModule,
    MatSelectModule,
    MatMenuModule,
    MatIconModule,
    // MatTabsModule,
    // FlexLayoutModule,
    // MatButtonToggleModule,
  ]
})
export class DashboardModule { }
