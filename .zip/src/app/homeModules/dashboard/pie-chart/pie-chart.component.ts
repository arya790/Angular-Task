import { Component, Input, OnInit } from '@angular/core';
import { ChartType, ChartOptions } from 'chart.js';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.scss']
})
export class PieChartComponent implements OnInit {
  @Input() payload:any = [];
  @Input() payloadDaTa:any = [];



  public pieChartOptions: ChartOptions = {
    responsive: true,
  };
  public colors = [
    {
      backgroundColor: [
        'rgba(255, 99, 132, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(0, 255, 0, 0.2)',
      ]
    }
  ]
  public pieChartLabels: Label[] = [];
  public pieChartData:  any = [];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartPlugins = [];

  doughnutChartLabels: Label[] = [];
  doughnutChartData: any=[]

  doughnutChartType: ChartType = 'doughnut';
  constructor() {
    monkeyPatchChartJsTooltip();
    monkeyPatchChartJsLegend();
  }



  ngOnInit(): void {
  }

}
