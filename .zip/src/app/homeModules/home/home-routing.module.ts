import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from 'src/app/auth/guard/auth.guard';

const routes: Routes = [
  {path:"",component:HomeComponent,
  children:[
  {
    path: 'dashboard',canActivate: [AuthGuard],
    loadChildren: () => import('../dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: 'petManagement',canActivate: [AuthGuard],
    loadChildren: () => import('../pet-manage/pet-manage.module').then(m => m.PetManageModule)
  },
  {
    path: 'veterinaryService',canActivate: [AuthGuard],
    loadChildren: () => import('../pet-service/pet-service.module').then(m => m.PetServiceModule)
  },

  ]
},
{ path: '**', redirectTo: '/home/dashboard', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
