import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { NavItem } from 'src/app/side-nav/components/menu-list/menu-list.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  @ViewChild('sidenav') sidenav!: MatSidenav;
  isExpanded = true;
  showSubmenu: boolean = false;
  isShowing = false;
  showFiller = false;
  vistorMenuAdded = false;
  close = false
  roleEmail: any
  showSubSubMenu: boolean = false;
  fixedMenus: NavItem[] = [
  ];
  menus = this.fixedMenus;

  selectedLocation: string = '';
  showLoader = false;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,

    private toastr: ToastrService,
    private loader: NgxUiLoaderService
  ) {

  }
  // mouseenter
  mouseenter() {
    if (!this.isExpanded) {
      this.isShowing = true;
    }
  }


  //mouseleave
  mouseleave() {
    if (!this.isExpanded) {
      this.isShowing = false;
    }
  }



  ngOnInit(): void {
    this.roleEmail = localStorage.getItem("role");
    this.handleRouteChange();


  }


  // handleRouteChange
  handleRouteChange() {
    const url = window.location.href;
    if (url.includes('home')) {
      this.goToRoute(false)
    }
  }


  // closeSidebar
  closeSidebar() {
    this.close = true
  }

  // openSidebar
  openSidebar() {
    this.close = false
  }


  // goToRoute
  goToRoute(shouldRedirect = true) {

    const item: NavItem[] = [

      {
        displayName: 'Dashboard',
        route: 'home/dashboard',
        iconName: 'dashboard',
        isSubSubmenu: false
      },
      {
        displayName: 'Pet Management',
        route: 'home/petManagement',
        iconName: 'edit',
        isSubSubmenu: false
      },
      {
        displayName: 'Veterinary  service',
        route: 'home/veterinaryService',
        iconName: 'chat',
        isSubSubmenu: false
      },
    ]
    if (this.roleEmail === "choudharyarya7906@gmail.com") {
      this.menus = [...item, ...this.fixedMenus];

    } else {
      let items = item.filter(item => item.displayName !== 'Dashboard');
      this.menus = [...items, ...this.fixedMenus];
    }

    this.menus = this.menus.map(res => {
      res.locationId = this.selectedLocation;
      res.children = res.children && res.children.map((route: any) => {
        route.locationId = this.selectedLocation;
        return route;
      })
      return res;
    })
    if (shouldRedirect) {
      this.router.navigate(['/home']);
    }
  }


  // logout
  logout() {
    this.router.navigate(['login']);
    this.toastr.success("Logout Sucessfully");
    localStorage.clear();
  }

}
