export interface addPetRecord{
    petName:string
    customerName:string
    email:String
    phoneNumber:String
    NoOfPets:string
}

export interface editRecord{
    record:addPetRecord
}