import { Component, Inject, OnInit } from '@angular/core';
import { addPetRecord } from '../Interface/petManage.interface';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { PetsService } from '../providers/pets.service';

@Component({
  selector: 'app-create-record',
  templateUrl: './create-record.component.html',
  styleUrls: ['./create-record.component.scss']
})
export class CreateRecordComponent implements OnInit {
  controls: any
  Id: any
  name:any='Aryan'
  showLoader: boolean = false
  recordForm: FormGroup = new FormGroup({
    petName: new FormControl('', Validators.required),
    NoOfPets:new FormControl('', Validators.required),
    customerName: new FormControl('', Validators.required),
    email: new FormControl('', Validators.required),
    phoneNumber:new FormControl('', [Validators.required,Validators.maxLength(10)]),
  });
  hide:boolean=false
dataRecive:any=[]
  constructor(
    private petService:PetsService,
    private ngxService: NgxUiLoaderService,
    private toaster: ToastrService,
    private dialogRef: MatDialogRef<CreateRecordComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any

  ) { }

  ngOnInit(): void {
    console.log(this.data,"data")

    if (this.data.record) {
    this.Id = this.data.record.id
      this.recordForm.patchValue(this.data.record)
    }
    this.controls = this.recordForm.controls;
  }

  // Submit Form
  submit() {
    if (this.data.record) {
      this.updateRecord()
    } else {
      this.addRecord()
    }
  }


  // addRecord
  addRecord() {
    if (this.recordForm.valid) {

      const data: addPetRecord = {
        petName: this.recordForm.controls['petName'].value,
        customerName: this.recordForm.controls['customerName'].value,
        email: this.recordForm.controls['email'].value,
        phoneNumber: this.recordForm.controls['phoneNumber'].value,
        NoOfPets:this.recordForm.controls['NoOfPets'].value,
      }
      this.showLoader = true
      this.ngxService.start();
      this.petService.createPetsData(data).subscribe((res: any) => {
        console.log(res, "ress")
        this.showLoader = false
        this.ngxService.stop();
        this.dialogRef.close(true);
        this.toaster.success("Record Added Successfully")
      })
    }

  }

 

  // updateRecord
  updateRecord() {
    if (this.data.record) {
      const data: addPetRecord = {
        petName: this.recordForm.controls['petName'].value,
        customerName: this.recordForm.controls['customerName'].value,
        email: this.recordForm.controls['email'].value,
        phoneNumber: this.recordForm.controls['phoneNumber'].value,
        NoOfPets:this.recordForm.controls['NoOfPets'].value,

      }
      this.showLoader = true
      this.ngxService.start();
      this.petService.editPetsData(this.Id, data).subscribe((res: any) => {
        console.log(res, "ress")
        this.showLoader = false
        this.ngxService.stop();
        this.dialogRef.close(true);
        this.toaster.success("Updated Successfully")
      })
    }

  }


}
