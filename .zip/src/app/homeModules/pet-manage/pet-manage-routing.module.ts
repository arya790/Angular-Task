import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewPetInfoComponent } from './view-pet-info/view-pet-info.component';

const routes: Routes = [
  {path:"",component:ViewPetInfoComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PetManageRoutingModule { }
