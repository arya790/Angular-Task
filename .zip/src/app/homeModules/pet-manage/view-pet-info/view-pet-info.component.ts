import { Component, OnInit, ViewChild } from '@angular/core';
import { ConfirmComponent } from 'src/app/homeModules/confirm/confirm.component';
import { CreateRecordComponent } from '../create-record/create-record.component';
import { editRecord } from '../Interface/petManage.interface';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';
import { MatPaginator } from '@angular/material/paginator';
import { PetsService } from '../providers/pets.service';

@Component({
  selector: 'app-view-pet-info',
  templateUrl: './view-pet-info.component.html',
  styleUrls: ['./view-pet-info.component.scss']
})
export class ViewPetInfoComponent implements OnInit {
  displayedColumns: string[] = ['No', 'petName', 'name','NoOfPets', 'email', 'phoneNumber','action'];
  dataSource: any = [];
  filteredEmployees: any = []
  length: any
  filterValue: any = []
  minSalary: any
  maxSalary: any
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  departmentFilterValue: any
  salaryFilterValue: any
  showLoader: any = false
  originalDataSource:any=[]
  p: any = 1
  name: any
  constructor(
    private petService:PetsService,
    private toastr: ToastrService,
    private ngxService: NgxUiLoaderService,
    private matdialog: MatDialog,
    private router: Router

  ) {

  }

  ngOnInit(): void {
    this.getPetsRecordData();
  }


  // getPetsRecordData
  getPetsRecordData() {
    this.petService.getPetsData().subscribe((res: any) => {
      console.log(res, "res")
      this.dataSource = res
      this.originalDataSource=res
      this.length = res.length
    })
  }


  // addPetsRecordDialogue
  addPetsRecordDialogue(records?: editRecord) {
    this.matdialog.open(CreateRecordComponent, {
      data: {
        record: records
      },
      width: "500px"
    }).afterClosed().subscribe((res: any) => {
      if (res) {
        this.getPetsRecordData();
      }
    })
  }



  //deletePetsInfo
  deletePetsInfo(employeeId: any) {
    this.matdialog.open(ConfirmComponent).afterClosed().subscribe((res:any) => {
      if (res == true) {
        this._deletePetsInfo(employeeId.id)
      }
    })
  }

  // _deletePetsInfo
  _deletePetsInfo(id: string) {
    console.log(id)
    this.showLoader = true;
    this.ngxService.start();
    this.petService.delete(id).subscribe((res: any) => {
      this.showLoader = false;
      this.ngxService.stop();
      this.toastr.success("Delete Sucessfully");
      if (res) {
        this.getPetsRecordData();
      }
    }, (error: any) => {
      this.toastr.error("Something went Wrong");
      this.showLoader = false;
      this.ngxService.stop();
    })
  }

  Search() {
    if (this.name === "") {
      this.dataSource = [...this.originalDataSource]; // Reset the dataSource to the original data
    } else {
      this.dataSource = this.originalDataSource.filter((res: any) => {
        if (res && res.petName) {
          return res.petName.toLowerCase().includes(this.name.toLowerCase()); // Case-insensitive search
        }
        return false; // Handle cases where res or res.name is undefined or null
      });
    }
  }

}
