export interface addPetService{
    name:string
    description:string
    price:String
}

export interface editService{
    service:addPetService
}