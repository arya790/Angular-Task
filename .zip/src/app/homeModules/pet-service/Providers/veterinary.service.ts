import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { addPetService } from '../Interface/veterinary.interface';

@Injectable({
  providedIn: 'root'
})
export class VeterinaryService {
  apiUrl:any='http://localhost:3000/petService'
  constructor(private http:HttpClient) { }

  // getPetsServiceData
  getPetsServiceData(): Observable<any> {
    return this.http.get<any[]>(`${this.apiUrl}`)
    .pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // post Data
  createPetsService(data: addPetService): Observable<any> {
    return this.http.post<any[]>(`${this.apiUrl}`, data).pipe(
      map((response: any) => {
        return response;
      })
    );
  }


  // editPetsService
  editPetService(id: number, data: addPetService): Observable<any> {
    return this.http.put<any[]>(`${this.apiUrl}/${id}`, data).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // Delete Service
  delete(Id: any): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${Id}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
