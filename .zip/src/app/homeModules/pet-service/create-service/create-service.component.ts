import { Component, Inject, OnInit } from '@angular/core';
import { addPetService } from '../Interface/veterinary.interface';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { PetsService } from '../../pet-manage/providers/pets.service';
import { ToastrService } from 'ngx-toastr';
import { VeterinaryService } from '../Providers/veterinary.service';

@Component({
  selector: 'app-create-service',
  templateUrl: './create-service.component.html',
  styleUrls: ['./create-service.component.scss']
})
export class CreateServiceComponent implements OnInit {
  controls: any
  Id: any
  name:any='Aryan'
  showLoader: boolean = false
  recordForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required),
    price: new FormControl('', Validators.required),
  });
  hide:boolean=false
dataRecive:any=[]
  constructor(
    private petService:VeterinaryService,
    private ngxService: NgxUiLoaderService,
    private toaster: ToastrService,
    private dialogRef: MatDialogRef<CreateServiceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any

  ) { }

  ngOnInit(): void {
    console.log(this.data,"data")

    if (this.data.record) {
    this.Id = this.data.record.id
      this.recordForm.patchValue(this.data.record)
    }
    this.controls = this.recordForm.controls;
  }


  // Submit Form
  submit() {
    if (this.data.record) {
      this.updateService()
    } else {
      this.addService()
    }
  }


  // addService
  addService() {
    if (this.recordForm.valid) {

      const data: addPetService = {
        name: this.recordForm.controls['name'].value,
        description: this.recordForm.controls['description'].value,
        price: this.recordForm.controls['price'].value,
      }
      this.showLoader = true
      this.ngxService.start();
      this.petService.createPetsService(data).subscribe((res: any) => {
        console.log(res, "ress")
        this.showLoader = false
        this.ngxService.stop();
        this.dialogRef.close(true);
        this.toaster.success("Record Added Successfully")
      })
    }

  }

 

  // updateService
  updateService() {
    if (this.data.record) {
      const data: addPetService = {
        name: this.recordForm.controls['name'].value,
        description: this.recordForm.controls['description'].value,
        price: this.recordForm.controls['price'].value,
      }
      this.showLoader = true
      this.ngxService.start();
      this.petService.editPetService(this.Id, data).subscribe((res: any) => {
        console.log(res, "ress")
        this.showLoader = false
        this.ngxService.stop();
        this.dialogRef.close(true);
        this.toaster.success("Updated Successfully")
      })
    }

  }


}
