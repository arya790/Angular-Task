import { Component, OnInit, ViewChild } from '@angular/core';
import { ConfirmComponent } from 'src/app/homeModules/confirm/confirm.component';
import { VeterinaryService } from '../Providers/veterinary.service';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { CreateServiceComponent } from '../create-service/create-service.component';
import { editService } from '../Interface/veterinary.interface';

@Component({
  selector: 'app-view-service',
  templateUrl: './view-service.component.html',
  styleUrls: ['./view-service.component.scss']
})
export class ViewServiceComponent implements OnInit {
  displayedColumns: string[] = ['No',  'name', 'description', 'price','action'];
  dataSource: any = [];
  filteredEmployees: any = []
  length: any
  filterValue: any = []
  minSalary: any
  maxSalary: any
  originalDataSource:any=[]
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  departmentFilterValue: any
  salaryFilterValue: any
  showLoader: any = false
  p: any = 1
  name: any
  constructor(
    private petService:VeterinaryService,
    private toastr: ToastrService,
    private ngxService: NgxUiLoaderService,
    private matdialog: MatDialog,
    private router: Router

  ) {

  }

  ngOnInit(): void {
    this.getPetsServiceData();
  }


  // getPetsServiceData
  getPetsServiceData() {
    this.petService.getPetsServiceData().subscribe((res: any) => {
      console.log(res, "res")
      this.dataSource = res
      this.originalDataSource=res
      this.length = res.length
    })
  }


  // addPetsRecordDialogue
  addPetsRecordDialogue(service?: editService) {
    this.matdialog.open(CreateServiceComponent, {
      data: {
        record: service
      },
      width: "500px"
    }).afterClosed().subscribe((res: any) => {
      if (res) {
        this.getPetsServiceData();
      }
    })
  }



  //deletePetsServiceInfo
  deletePetsServiceInfo(Id: any) {
    this.matdialog.open(ConfirmComponent).afterClosed().subscribe((res:any) => {
      if (res == true) {
        this._deletePetsServiceInfo(Id.id)
      }
    })
  }

  // _deletePetsServiceInfo
  _deletePetsServiceInfo(id: string) {
    console.log(id)
    this.showLoader = true;
    this.ngxService.start();
    this.petService.delete(id).subscribe((res: any) => {
      this.showLoader = false;
      this.ngxService.stop();
      this.toastr.success("Delete Sucessfully");
      if (res) {
        this.getPetsServiceData();
      }
    }, (error: any) => {
      this.toastr.error("Something went Wrong");
      this.showLoader = false;
      this.ngxService.stop();
    })
  }


    // Search Filter
    Search() {
      if (this.name === "") {
        this.dataSource = [...this.originalDataSource]; 
      } else {
        this.dataSource = this.originalDataSource.filter((res: any) => {
          return res.name.toLowerCase().includes(this.name.toLowerCase()); 
        });
      }
    }


}
